-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 06, 2024 at 03:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `olimpiadas`
--

-- --------------------------------------------------------

--
-- Table structure for table `medalha`
--

CREATE TABLE `medalha` (
  `id_medalha` int(11) NOT NULL,
  `pais` varchar(150) NOT NULL,
  `modalidade` varchar(250) NOT NULL,
  `ouro` int(11) NOT NULL,
  `prata` int(11) NOT NULL,
  `bronze` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medalha`
--

INSERT INTO `medalha` (`id_medalha`, `pais`, `modalidade`, `ouro`, `prata`, `bronze`) VALUES
(4, 'República Popular da China', 'Atletismo', 1, 1, 0),
(5, 'República Popular da China', 'Badminton', 2, 3, 0),
(6, 'República Popular da China', 'Ciclismo BMX Freestyle', 1, 0, 0),
(7, 'República Popular da China', 'Ginástica Artística', 2, 5, 2),
(8, 'República Popular da China', 'Ginástica de Trampolim', 0, 1, 1),
(9, 'República Popular da China', 'Judô', 0, 0, 1),
(10, 'República Popular da China', 'Natação', 2, 3, 7),
(11, 'República Popular da China', 'Saltos Ornamentais', 4, 0, 0),
(12, 'República Popular da China', 'Tênis', 1, 1, 0),
(13, 'República Popular da China', 'Tênis de Mesa', 3, 1, 0),
(14, 'República Popular da China', 'Tiro com Arco', 0, 1, 0),
(15, 'República Popular da China', 'Tiro Esportivo', 5, 2, 3),
(16, 'Estados Unidos da América', 'Atletismo', 3, 4, 4),
(17, 'Estados Unidos da América', 'Basquete 3x3', 0, 0, 1),
(18, 'Estados Unidos da América', 'Canoagem Slalom', 0, 0, 1),
(19, 'Estados Unidos da América', 'Ciclismo BMX Freestyle', 0, 1, 0),
(20, 'Estados Unidos da América', 'Ciclismo de Estrada', 1, 0, 1),
(21, 'Estados Unidos da América', 'Ciclismo Mountain Bike', 0, 1, 0),
(22, 'Estados Unidos da América', 'Esgrima', 2, 1, 1),
(23, 'Estados Unidos da América', 'Ginástica Artística\r\n', 3, 1, 6),
(24, 'Estados Unidos da América', 'Golfe', 1, 0, 0),
(25, 'Estados Unidos da América', 'Hipismo', 0, 1, 0),
(26, 'Estados Unidos da América', 'Natação', 8, 13, 7),
(27, 'Estados Unidos da América', 'Remo', 1, 0, 1),
(28, 'Estados Unidos da América', 'Rugby Sevens', 0, 0, 1),
(29, 'Estados Unidos da América', 'Saltos Ornamentais\r\n', 0, 1, 0),
(30, 'Estados Unidos da América', 'Skate', 0, 1, 1),
(31, 'Estados Unidos da América', 'Tênis', 0, 1, 1),
(32, 'Estados Unidos da América', 'Tiro com Arco', 0, 1, 1),
(33, 'Estados Unidos da América', 'Tiro Esportivo', 1, 3, 1),
(34, 'Estados Unidos da América', 'Triatlo', 0, 1, 0),
(35, 'Estados Unidos da América', 'Vela ', 0, 0, 1),
(36, 'Austrália', 'Atletismo', 0, 1, 2),
(37, 'Austrália', 'Canoagem Slalom', 3, 0, 0),
(38, 'Austrália', 'Ciclismo BMX Freestyle', 0, 0, 1),
(39, 'Austrália', 'Ciclismo BMX Racing\r\n', 1, 0, 0),
(40, 'Austrália', 'Ciclismo de Estrada', 1, 0, 0),
(41, 'Austrália', 'Hipismo', 0, 1, 0),
(42, 'Austrália', 'Natação', 7, 8, 3),
(43, 'Austrália', 'Remo', 0, 0, 1),
(44, 'Austrália', 'Tênis', 1, 0, 0),
(45, 'Austrália', 'Tiro Esportivo', 0, 0, 1),
(46, 'Austrália', 'Vela', 0, 1, 0),
(47, 'França', 'Basquete 3x3', 0, 1, 0),
(48, 'França', 'Canoagem Slalom', 1, 2, 0),
(49, 'França', 'Ciclismo BMX Freestyle', 0, 0, 1),
(50, 'França', 'Ciclismo BMX Racing', 1, 1, 1),
(51, 'França', 'Ciclismo de Estrada', 0, 1, 1),
(52, 'França', 'Ciclismo Mountain Bike', 1, 1, 0),
(53, 'França', 'Esgrima', 1, 4, 2),
(54, 'França', 'Hipismo', 0, 1, 1),
(55, 'França', 'Judô', 2, 2, 6),
(56, 'França', 'Natação', 4, 1, 2),
(57, 'França', 'Rugby Sevens', 1, 0, 0),
(58, 'França', 'Surfe', 0, 0, 1),
(59, 'França', 'Tênis de Mesa', 0, 0, 1),
(60, 'França', 'Tiro com Arco', 0, 1, 1),
(61, 'França', 'Tiro Esportivo', 0, 1, 0),
(62, 'França', 'Triatlo', 1, 0, 1),
(63, 'França', 'Vela', 0, 0, 1),
(64, 'Grã-Bretanha', 'Atletismo', 1, 0, 1),
(65, 'Grã-Bretanha', 'Canoagem Slalom', 0, 2, 2),
(66, 'Grã-Bretanha', 'Ciclismo BMX Freestyle', 0, 1, 0),
(67, 'Grã-Bretanha', 'Ciclismo de Estrada', 0, 1, 0),
(68, 'Grã-Bretanha', 'Ciclismo de Pista', 1, 0, 0),
(69, 'Grã-Bretanha', 'Ciclismo Mountain Bike', 1, 0, 0),
(70, 'Grã-Bretanha', 'Ginástica Artística', 0, 0, 2),
(71, 'Grã-Bretanha', 'Ginástica de Trampolim', 1, 0, 0),
(72, 'Grã-Bretanha', 'Golfe', 0, 1, 0),
(73, 'Grã-Bretanha', 'Hipismo', 2, 0, 3),
(74, 'Grã-Bretanha', 'Natação', 1, 4, 0),
(75, 'Grã-Bretanha', 'Remo', 3, 2, 3),
(76, 'Grã-Bretanha', 'Saltos Ornamentais', 0, 1, 3),
(77, 'Grã-Bretanha', 'Tiro Esportivo', 1, 1, 0),
(78, 'Grã-Bretanha', 'Triatlo', 1, 0, 2),
(79, 'Grã-Bretanha', 'Vela\r\n', 0, 0, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `medalha`
--
ALTER TABLE `medalha`
  ADD PRIMARY KEY (`id_medalha`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `medalha`
--
ALTER TABLE `medalha`
  MODIFY `id_medalha` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
